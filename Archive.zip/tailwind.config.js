module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        card: '#0F1724',
        primary: '#00E5FF',
        accent: '#FF2D95',
        highlight: '#FFD166',
        muted: '#94A3B8',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
        display: ['"Poppins"', 'Inter', 'sans-serif'],
      },
      boxShadow: {
        neon: '0 6px 18px rgba(0,229,255,0.06), inset 0 1px 0 rgba(255,255,255,0.02)',
        card: '0 6px 24px rgba(2,6,23,0.6)',
      },
    },
  },
  plugins: [],
}
